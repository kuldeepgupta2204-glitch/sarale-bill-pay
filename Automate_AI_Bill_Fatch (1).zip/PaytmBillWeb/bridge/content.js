// Paytm par bulk bijli bill fetch: operator + number bharo, due date aur amount padho, queue me save karo.
// Koi payment nahi hota. Status side panel me dikhta hai.
(async () => {
  const { queue: q0 } = await chrome.storage.local.get("queue");
  if (!q0 || !q0.active) return;
  const isTop = window === window.top;
  const myIdx = q0.idx;
  const item = q0.items[myIdx];
  if (!item || item.status !== "pending") return;

  // ---- Helpers ----
  function qsaAll(sel, root = document) {
    const out = [...root.querySelectorAll(sel)];
    for (const el of root.querySelectorAll("*")) if (el.shadowRoot) out.push(...qsaAll(sel, el.shadowRoot));
    return out;
  }
  const visible = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  let timer, obs = null, lastT = "", stopped = false;
  const status = (t, c) => { if (t === lastT) return; lastT = t; chrome.storage.local.set({ lastStatus: { t, c: c || "#111", at: Date.now() } }); };
  const idle = (t, c) => { if (isTop) status(t, c); };
  const stopAll = () => { stopped = true; clearInterval(timer); if (obs) obs.disconnect(); };
  const norm = (s) => (s || "").toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
  const txt = (e) => (e.innerText || e.value || "").trim();

  function setValue(input, value) {
    const proto = input.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  // operator ke naam se best match (shabdon ka overlap)
  function score(text, op) {
    const t = norm(text), words = norm(op).split(" ").filter((w) => w.length > 2);
    if (!words.length) return 0;
    return words.filter((w) => t.includes(w)).length / words.length;
  }

  // ---- Fuzzy board matching: Excel me jo naam likha ho use Paytm ki list ke naam se pehchano ----
  // (spelling galat, short form/full form, Hindi-English shabd, extra/kam shabd - sab chalega)
  const SYN = { dakshin: "south", uttar: "north", paschim: "west", purv: "east", purvanchal: "east", madhyanchal: "central", madhya: "central",
    bijli: "electricity", vidyut: "electricity", electric: "electricity", vitran: "distribution", nigam: "corporation", corp: "corporation",
    ltd: "limited", pvt: "private", cos: "company", co: "company", vibhag: "department", dept: "department" };
  const GENERIC = new Set(["electricity", "board", "company", "corporation", "limited", "private", "the", "of", "and", "state", "distribution", "supply", "department", "services"]);
  const STOPW = new Set(["limited", "private", "the", "of", "and", "co", "company"]);
  // Purane/alag naam -> board ka naya/asli naam (naya alias jodna ho to yahan ek line add kar do)
  const ALIAS = { mahavitran: "msedcl maharashtra state electricity distribution", mseb: "msedcl maharashtra state electricity distribution",
    tneb: "tangedco tamil nadu generation distribution", tangedco: "tamil nadu generation and distribution corporation",
    kseb: "kerala state electricity board", wbsedcl: "west bengal state electricity distribution",
    nesco: "north eastern electricity supply company", pvvnl: "paschimanchal vidyut vitran nigam", dvvnl: "dakshinanchal vidyut vitran nigam",
    puvvnl: "purvanchal vidyut vitran nigam", mvvnl: "madhyanchal vidyut vitran nigam", kesco: "kanpur electricity supply company",
    cesc: "calcutta electric supply corporation", bescom: "bangalore electricity supply company", tpddl: "tata power delhi distribution",
    ndpl: "tata power delhi distribution", brpl: "bses rajdhani power", bypl: "bses yamuna power", adani: "adani electricity mumbai",
    reliance: "adani electricity mumbai", torrent: "torrent power", dgvcl: "dakshin gujarat vij company", ugvcl: "uttar gujarat vij company",
    mgvcl: "madhya gujarat vij company", pgvcl: "paschim gujarat vij company" };
  const toks = (s) => norm(s).split(" ").filter(Boolean).map((w) => SYN[w] || w);
  function lev(a, b) {
    const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  function tokSim(a, b) {
    if (a === b) return 1;
    const mn = Math.min(a.length, b.length);
    if (mn >= 3 && (a.startsWith(b) || b.startsWith(a))) return 0.9;
    // spelling ki galti sirf asli shabdon me maano; JVVNL/MVVNL jaise short form (bina vowel) me ek akshar ka fark alag board hota hai
    if (mn >= 5 && /[aeiou]/.test(a) && /[aeiou]/.test(b)) { const sim = 1 - lev(a, b) / Math.max(a.length, b.length); if (sim >= 0.75) return sim * 0.95; }
    return 0;
  }
  const dice = (a, b) => {
    const g = (s) => { const m = new Map(); for (let i = 0; i < s.length - 2; i++) { const t = s.slice(i, i + 3); m.set(t, (m.get(t) || 0) + 1); } return m; };
    if (a.length < 3 || b.length < 3) return 0;
    const A = g(a), B = g(b); let hit = 0, na = 0, nb = 0;
    A.forEach((v, k) => { na += v; if (B.has(k)) hit += Math.min(v, B.get(k)); }); B.forEach((v) => { nb += v; });
    return (2 * hit) / (na + nb);
  };
  function initialsVariants(t) { // ["uttar","pradesh","power","corporation","limited"] -> upplc.. ke alag alag roop
    const raw = norm(String(t).replace(/\(.*?\)/g, " ")).split(" ").filter(Boolean);
    const a = raw.map((w) => w[0]).join(""), b = raw.filter((w) => !STOPW.has(w)).map((w) => w[0]).join("");
    return [...new Set([a, b])].filter((x) => x.length >= 2);
  }
  // 0..1: wanted (Excel ka naam) option (Paytm list ka naam) se kitna milta hai
  function fscore(optText, wanted) {
    const a = ALIAS[norm(wanted).replace(/ /g, "")], c = resolveCode(wanted);
    return Math.max(fscore0(optText, wanted), a ? 0.95 * fscore0(optText, a) : 0, c ? 0.97 * Math.max(fscore0(optText, CODES[c]), fscore0(optText, c.replace(/_/g, " "))) : 0);
  }
  function fscore0(optText, wanted) {
    const ot = norm(optText), wt = norm(wanted);
    if (!ot || !wt) return 0;
    if (ot === wt) return 1;
    const O = toks(optText), W = toks(wanted);
    let wSum = 0, wHit = 0;
    for (const w of W) { const wt_ = GENERIC.has(w) ? 0.3 : 1; wSum += wt_; wHit += wt_ * Math.max(0, ...O.map((o) => tokSim(w, o))); }
    let oSum = 0, oHit = 0;
    for (const o of O) { const wt_ = GENERIC.has(o) ? 0.3 : 1; oSum += wt_; oHit += wt_ * Math.max(0, ...W.map((w) => tokSim(w, o))); }
    let best = wSum && oSum ? 0.75 * (wHit / wSum) + 0.25 * (oHit / oSum) : 0;
    // short form <-> full form (UPPCL <-> Uttar Pradesh Power Corporation Limited)
    const wc = wt.replace(/ /g, ""), oc = ot.replace(/ /g, "");
    if (W.length === 1 && wc.length >= 3 && wc.length <= 9) for (const v of initialsVariants(optText)) if (v === wc || (wc.length >= 4 && (v.startsWith(wc) || wc.startsWith(v) && v.length >= 4))) best = Math.max(best, v === wc ? 0.92 : 0.8);
    for (const w of W) if (w.length >= 4 && w.length <= 9 && !/[aeiou]/.test(w) && O.includes(w)) best = Math.max(best, 0.88); // short form (jaise MVVNL) option me likha ho
    if (W.length > 1) for (const w of W) if (w.length >= 4 && w.length <= 9) for (const v of initialsVariants(optText)) if (v === w) best = Math.max(best, 0.85);
    if (O.length === 1 && oc.length >= 3 && oc.length <= 9) for (const v of initialsVariants(wanted)) if (v === oc) best = Math.max(best, 0.92);
    best = Math.max(best, wc.length >= 8 && oc.length >= 8 ? dice(wc, oc) * 0.9 : 0, wc.length >= 4 && oc.includes(wc) ? 0.7 : 0);
    return Math.min(1, best);
  }
  // Paytm ke board naam (code) -> unke poore/aam naam. Naya board aaye to yahan ek line add kar do.
  const CODES = {
    AdaniElectricityMumbai: "adani electricity mumbai", APEPDCL: "apepdcl eastern power distribution andhra pradesh", BESCOM: "bescom bangalore electricity supply company",
    BEST: "best brihanmumbai electric supply transport undertaking mumbai", BSESRajdhani: "bses rajdhani power delhi", BSESYamuna: "bses yamuna power delhi",
    CESCOM: "cescom chamundeshwari electricity supply mysore", CESE: "cese cesc calcutta kolkata electric supply corporation", CHENNAIMWATERS: "chennai metro water",
    CSPDCL: "cspdcl chhattisgarh state power distribution", DGVCL: "dgvcl dakshin gujarat vij company", DHBVN: "dhbvn dakshin haryana bijli vitran nigam",
    GESCOM: "gescom gulbarga electricity supply company", HPSEBL: "hpsebl himachal pradesh state electricity board", JBVNL: "jbvnl jharkhand bijli vitran nigam",
    JDVVNL: "jdvvnl jodhpur vidyut vitran nigam", JKPDD: "jkpdd jammu kashmir power development department", JUSCO: "jusco jamshedpur utilities",
    JVVNL: "jvvnl jaipur vidyut vitran nigam", KESCO: "kesco kanpur electricity supply company", KSEB: "kseb kerala state electricity board",
    MESCOM: "mescom mangalore electricity supply company", MGVCL: "mgvcl madhya gujarat vij company", MPMKVV_URBAN: "mpmkvvcl madhya pradesh madhya kshetra vidyut vitran urban bhopal",
    MPPKVV: "mppkvvcl madhya pradesh paschim kshetra vidyut vitran indore", MPPKVV_JBPRNGB: "mppkvvcl jbprngb jabalpur",
    MSEDCL: "msedcl maharashtra state electricity distribution mahavitran", NBPDCL: "nbpdcl north bihar power distribution", NPCL: "npcl noida power company",
    PGVCL: "pgvcl paschim gujarat vij company", PSPCL: "pspcl punjab state power corporation", TATAPOWERLTD_DELHI: "tata power delhi distribution tpddl",
    TATAPOWERLTD_MUMBAI: "tata power mumbai", TORRENTPOWER_AGRA: "torrent power agra", TORRENTPOWER_AHMD: "torrent power ahmedabad",
    TPCODL: "tpcodl tata power central odisha distribution", TSNPDCL: "tsnpdcl telangana northern power distribution", UGVCL: "ugvcl uttar gujarat vij company",
    UHBVN: "uhbvn uttar haryana bijli vitran nigam", UPCL: "upcl uttarakhand power corporation", UPPCLU_DVVNL: "uppcl dvvnl dakshinanchal vidyut vitran agra",
    UPPCLU_MVVNL: "uppcl mvvnl madhyanchal vidyut vitran lucknow", UPPCLU_PUVNL: "uppcl puvvnl purvanchal vidyut vitran varanasi",
    UPPCLU_PVVNL: "uppcl pvvnl paschimanchal vidyut vitran meerut", WBSEDCL: "wbsedcl west bengal state electricity distribution",
  };
  const codeCache = new Map();
  // Excel ka naam -> Paytm ka board code (sirf jab ek hi board saaf-saaf match ho; UPPCL jaise naam jo kai boards ke hain unme null)
  function resolveCode(wanted) {
    const key = norm(wanted); if (!key) return null;
    if (codeCache.has(key)) return codeCache.get(key);
    const flat = key.replace(/ /g, ""); let res = null;
    const exact = Object.keys(CODES).find((c) => c.toLowerCase().replace(/_/g, "") === flat);
    if (exact) res = exact;
    else {
      const sc = Object.entries(CODES).map(([c, ph]) => [c, fscore0(ph, wanted)]).sort((a, b) => b[1] - a[1]);
      if (sc[0][1] >= 0.75 && sc[0][1] - sc[1][1] >= 0.12) res = sc[0][0];
    }
    codeCache.set(key, res); return res;
  }
  // Paytm ki search box me type karne ke liye alag alag naam: pura -> khaas shabd -> short form
  function boardQueries(wanted) {
    const W = norm(wanted).split(" ").filter(Boolean), key = W.filter((w) => w.length >= 3 && !GENERIC.has(SYN[w] || w)).sort((a, b) => b.length - a.length);
    const cd = resolveCode(wanted), al = ALIAS[norm(wanted).replace(/ /g, "")] || (cd && CODES[cd]);
    const q = [...(cd ? [CODES[cd].split(" ")[0]] : []), wanted, ...(al && !cd ? [al.split(" ").slice(0, 3).join(" ")] : []), ...key.slice(0, 2), ...(W.length > 1 ? initialsVariants(wanted).filter((x) => x.length >= 3).slice(0, 1) : [])];
    if (key[0] && key[0].length > 5) q.push(key[0].slice(0, 4));
    return [...new Set(q.map((x) => x.trim()).filter(Boolean))].slice(0, 5);
  }
  const FZ_OK = 0.6, FZ_LAST = 0.5;
  function bestOption(op) {
    return qsaAll("li,a,button,[role=button],[role=option],div,span,label,p")
      .filter((e) => visible(e) && !e.closest("nav,header,footer") && txt(e).length > 2 && txt(e).length < 100)
      .map((e) => ({ e, s: score(txt(e), op), len: txt(e).length }))
      .filter((x) => x.s >= 0.6)
      .sort((a, b) => b.s - a.s || a.len - b.len)[0];
  }
  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (m.type === "debug") {
      const items = qsaAll("button,a,[role],input,select,textarea,label,h1,h2,h3").filter(visible).map((e) =>
        `${e.tagName}${e.type ? "[" + e.type + "]" : ""}${e.placeholder ? "{ph:" + e.placeholder + "}" : ""}: ${txt(e).slice(0, 70).replace(/\n/g, " ") || e.getAttribute("aria-label") || e.id || ""}`).slice(0, 90);
      send({ out: `FRAME: ${isTop ? "TOP" : "IFRAME"} URL: ${location.href}\nTEXT: ${(document.body.innerText || "").replace(/\s+/g, " ").slice(0, 1000)}\n` + items.join("\n") });
    }
    if (m.type === "stop") { stopAll(); status("Stopped."); }
  });

  // ---- Queue update (sirf tabhi jab ye bill abhi bhi 'pending' ho -> double save nahi hoga) ----
  async function finish(statusVal, data) {
    stopAll();
    // Excel me Type khali tha to jo Paytm par chuna gaya (jaise "Bill Payment") wahi report me bhar do
    let distVal = ""; try { distVal = ((typeof fieldInfo === "function" && fieldInfo(/^district(\s*\/\s*type)?$|^type$/i)) || {}).value || ""; } catch (_) {}
    let next = null, startUrl = "";
    const { queue } = await chrome.storage.local.get("queue");
    if (!queue || !queue.active || queue.idx !== myIdx || queue.items[myIdx].status !== "pending") return;
    Object.assign(queue.items[myIdx], data, { status: statusVal });
    if (distVal && !queue.items[myIdx].district) queue.items[myIdx].district = distVal.trim();
    try { const cd = resolveCode(queue.items[myIdx].operator); if (cd) queue.items[myIdx].boardCode = cd; } catch (_) {}
    try { const bv = ((fieldInfo(/electricity\s*board(?!s)|^board$|operator|discom|provider/i) || {}).value || "").trim(); if (bv) queue.items[myIdx].paytmBoard = bv; } catch (_) {}
    const fails = statusVal === "error" ? (queue.fails || 0) + 1 : 0;
    queue.fails = fails;
    const n = queue.items.findIndex((b, i) => i > myIdx && b.status === "pending");
    if (fails >= 3) { queue.active = false; }
    else if (n >= 0) { queue.idx = n; queue.startedAt = Date.now() + (queue.delay ?? 1) * 1000; next = n; }
    else queue.active = false;
    startUrl = queue.startUrl;
    await chrome.storage.local.set({ queue });
    if (fails >= 3) { status("⚠ 3 bills failed in a row, so it stopped. Click “Show Paytm window” to check the page (you may need to log in again).", "#b12704"); chrome.runtime.sendMessage({ type: "detach" }); }
    else if (next !== null) {
      status(`✔ ${myIdx + 1}/${queue.items.length} done. Next bill...`, "#067d62");
      setTimeout(() => chrome.runtime.sendMessage({ type: "navigate", url: startUrl }), (queue.delay ?? 1) * 1000);
    } else { status("🎉 All bills fetched. Click “Download Excel report”.", "#067d62"); chrome.runtime.sendMessage({ type: "detach" }); }
  }

  // ---- Step 1: State -> Electricity Board -> (District/Type) -> CA Number -> Proceed ----
  let fetchedAt = q0.fetchedIdx === myIdx ? q0.fetchedAt || 0 : 0; // page badalne par bhi yaad rahe
  let numDone = false, numAt = 0;
  const isInHeader = (e) => e.closest("header,nav,[class*=header],[class*=Header],[id*=header]");

  // Form ka field dhoondho: label (jaise "State") + uske paas wala input (label input ke baad bhi ho sakta hai)
  const INPUT_SEL = "input:not([type=radio]):not([type=checkbox]):not([type=hidden]):not([type=submit]),select";
  const dist = (a, b) => { const r = a.getBoundingClientRect(), s = b.getBoundingClientRect(); return Math.hypot(r.left - s.left, r.top - s.top); };
  function fieldInfo(labelRe) {
    const labels = qsaAll("label,span,div,p,legend").filter((e) => visible(e) && !e.closest("a") && !isInHeader(e)
      && !e.children.length && labelRe.test(txt(e)) && txt(e).length < 30);
    for (const lab of labels) {
      let input = lab.control || null, box = lab.parentElement;
      for (let i = 0; !input && i < 3 && box; i++, box = box.parentElement) {
        const list = [...box.querySelectorAll(INPUT_SEL)].filter((x) => visible(x) || x.type === "text");
        if (list.length) input = list.sort((a, b) => dist(a, lab) - dist(b, lab))[0];
      }
      if (input) {
        const value = input.tagName === "SELECT" ? (input.options[input.selectedIndex] || {}).text || "" : (input.value || "").trim();
        return { box: input.parentElement || lab, input, lab, value };
      }
      // input na mile to text se value nikalo (purana tareeka)
      let b = lab.parentElement;
      for (let i = 0; i < 4 && b; i++, b = b.parentElement) {
        const t = txt(b), r = b.getBoundingClientRect();
        if (t.length > txt(lab).length + 1 && r.height <= 160 && r.width >= 150) return { box: b, input: null, lab, value: t.replace(txt(lab), "").replace(/\s+/g, " ").trim() };
      }
    }
    // label na mile to input ke placeholder / aria-label / name se dhoondho
    const byAttr = qsaAll(INPUT_SEL).find((i) => visible(i) && !isInHeader(i) && labelRe.test(`${i.placeholder} ${i.getAttribute("aria-label") || ""} ${i.name} ${i.id}`));
    if (byAttr) return { box: byAttr.parentElement || byAttr, input: byAttr, lab: byAttr, value: (byAttr.value || "").trim() };
    return null;
  }
  // Board ke liye aakhri tareeka: state ke baad jo pehla khali dropdown-input dikhe
  function emptyInputInfo() {
    const used = Object.values(fsm).map((f) => f.input);
    const i = qsaAll(INPUT_SEL).filter((x) => visible(x) && x.tagName === "INPUT" && ["text", "search", ""].includes(x.type) && !x.value && !isInHeader(x) && !used.includes(x))[0];
    return i ? { box: i.parentElement || i, input: i, lab: i, value: "" } : null;
  }

  const fsm = {};
  // Asli insaan jaisa click: pointerdown -> mousedown -> pointerup -> mouseup -> click (dropdown options aksar mousedown par chalte hain)
  function realClick(el) {
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, button: 0, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      el.dispatchEvent(new (t.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent)(t, o));
    }
  }
  // Asli (trusted) typing / click: background se Chrome debugger ke zariye. Fail ho to purana tareeka.
  const bg = (m) => new Promise((res) => { if (stopped) { res({ ok: false }); return; } try { chrome.runtime.sendMessage(m, (r) => res(r || { ok: false })); } catch (_) { res({ ok: false }); } });
  async function trustedType(el, text) {
    if (stopped) return false;
    el.focus(); if (el.select) el.select();
    const r = await bg({ type: "typeText", text, clear: true });
    if (!r.ok) setValue(el, text);
    return r.ok;
  }
  async function clickEl(el) {
    if (stopped) return false;
    let r = el.getBoundingClientRect();
    // sirf tab scroll karo jab element screen ke bahar ho (warna khula dropdown band ho jata hai)
    if (r.top < 0 || r.bottom > window.innerHeight) { try { el.scrollIntoView({ block: "center" }); } catch (_) {} r = el.getBoundingClientRect(); }
    if (isTop && r.width && r.height) {
      const res = await bg({ type: "clickAt", x: r.left + r.width / 2, y: r.top + r.height / 2 });
      if (res.ok) return true;
    }
    realClick(el);
    return false;
  }
  const OPT_SEL = "li,button,[role=button],[role=option],div,span,label,p,a";

  // Ek dropdown field chuno: kholo -> naam type karo -> list me dikhne wali option par click karo
  // true = ho gaya, false = abhi chal raha hai
  function selectField(key, label, labelRe, wanted, opts = {}) {
    const F = (fsm[key] = fsm[key] || { phase: "idle", at: 0, tries: 0, typed: false, snap: null, touched: false });
    const fz = key === "board"; // sirf Electricity Board ke liye fuzzy match
    const okVal = (v) => score(v, wanted) >= 0.6 || (fz && (fscore(v, wanted) >= FZ_OK || (F.pickedText && norm(v) === norm(F.pickedText))));
    let info = fieldInfo(labelRe);
    if (!info && key === "board") info = emptyInputInfo();
    if (!info) { idle(`Looking for the "${label}" field...`); return false; }
    if (F.busy) return false;
    if (!F.touched && okVal(info.value)) return true; // pehle se sahi chuna hua tha (hamne chhua nahi)
    if (!F.touched && opts.acceptAnyPrefilled && info.value) return true;
    const native = info.input && info.input.tagName === "SELECT" ? info.input : info.box.querySelector("select");
    if (native) {
      const o = [...native.options].map((o) => ({ o, s: score(o.text, wanted) })).sort((a, b) => b.s - a.s)[0];
      if (o && o.s >= 0.6) { native.value = o.o.value; native.dispatchEvent(new Event("change", { bubbles: true })); return true; }
    }
    if (F.tries > 3) { finish("error", { note: `${label} "${wanted}" could not be selected`, due: "-", amount: null, name: "" }); return false; }

    if (F.phase === "idle") {
      F.snap = new WeakSet(qsaAll("*").filter(visible));
      F.input = info.input; F.touched = true; F.typed = false; F.qi = 0; F.pickedText = ""; F.qAt = 0;
      F.queries = fz ? boardQueries(wanted) : [wanted];
      const target = info.input || info.box;
      F.phase = "opened"; F.at = Date.now(); F.busy = true;
      status(`Opening ${label}: ${wanted}`);
      clickEl(target).then(() => { F.busy = false; F.at = Date.now(); });
      return false;
    }
    const isNew = (e) => visible(e) && !F.snap.has(e);
    // Dropdown pehle se khula ho (snapshot me aa gaya) to "naya" wali pehchan fail hoti thi -> position se pehchano:
    // input ke theek neeche, usi chaudai me dikhne wale elements bhi option maane jayenge
    const anchor = info.input || info.box;
    const fresh = (e) => {
      if (isNew(e)) return true;
      if (!visible(e) || e.contains(anchor)) return false;
      const a = anchor.getBoundingClientRect(), r = e.getBoundingClientRect();
      return r.top >= a.bottom - 4 && r.top < a.bottom + 420 && r.right > a.left && r.left < a.right + 40;
    };
    if (F.phase === "opened") {
      if (Date.now() - F.at < 250) return false;
      const search = qsaAll("input").find((i) => isNew(i) && ["text", "search", ""].includes(i.type));
      if (search && !F.typed) { F.typed = true; F.busy = true; status(`${label}: typing "${wanted}"...`); F.qAt = Date.now(); trustedType(search, F.queries[F.qi] || wanted).then(() => { F.busy = false; F.at = Date.now(); }); return false; }
      if (!search && !F.typed && info.input && info.input.tagName === "INPUT" && !info.input.readOnly) { F.typed = true; F.busy = true; status(`${label}: typing "${wanted}"...`); F.qAt = Date.now(); trustedType(info.input, F.queries[F.qi] || wanted).then(() => { F.busy = false; F.at = Date.now(); }); return false; }
      if (F.typed && Date.now() - F.at < 450) return false; // suggestions aane do
      const w = norm(wanted);
      const opt = qsaAll(OPT_SEL)
        .filter((e) => fresh(e) && e !== info.input && e.tagName !== "INPUT" && txt(e).length > 1 && txt(e).length < 80 && !(e.tagName === "A" && !/^#|^$|javascript/.test(e.getAttribute("href") || "")))
        .map((e) => ({ e, s: fz ? Math.max(score(txt(e), wanted), fscore(txt(e), wanted)) : score(txt(e), wanted), eq: norm(txt(e)) === w, len: txt(e).length }))
        .filter((x) => x.s >= 0.6 || (fz && x.s >= FZ_OK))
        .sort((a, b) => b.eq - a.eq || b.s - a.s || a.len - b.len)[0];
      let pick = opt;
      if (fz && !pick) {
        const waited = Date.now() - (F.qAt || F.at);
        if (waited > 1700 && F.qi < F.queries.length - 1) { // is naam se list me kuch nahi mila -> agla (chhota) naam try karo
          F.qi++; F.typed = false; F.at = Date.now(); status(`${label}: "${wanted}" not found, trying "${F.queries[F.qi]}"...`); return false;
        }
        if (waited > 1700 && F.qi >= F.queries.length - 1) { // sab naam try ho gaye: list me jo sabse kareeb ho wahi chuno (kam threshold)
          const loose = qsaAll(OPT_SEL)
            .filter((e) => fresh(e) && e !== info.input && e.tagName !== "INPUT" && txt(e).length > 1 && txt(e).length < 80 && !(e.tagName === "A" && !/^#|^$|javascript/.test(e.getAttribute("href") || "")))
            .map((e) => ({ e, s: fscore(txt(e), wanted), len: txt(e).length })).filter((x) => x.s >= FZ_LAST).sort((a, b) => b.s - a.s || a.len - b.len)[0];
          if (loose) pick = loose;
        }
      }
      if (!pick && opts.anyFallback && Date.now() - F.at > 1800) {
        // Excel me value nahi di aur default naam nahi mila: list ka pehla option chuno
        const first = qsaAll(OPT_SEL).filter((e) => fresh(e) && e !== info.input && e.tagName !== "INPUT" && !e.children.length && txt(e).length > 1 && txt(e).length < 40
          && !(e.tagName === "A" && !/^#|^$|javascript/.test(e.getAttribute("href") || "")))[0];
        if (first) pick = { e: first };
      }
      if (pick) { const opt = pick; F.pickedText = txt(opt.e); F.phase = "picked"; F.at = Date.now(); F.busy = true; clickEl(opt.e).then(() => { F.busy = false; F.at = Date.now(); }); status(`${label}: selected "${txt(opt.e).slice(0, 40)}"`); return false; }
      if (Date.now() - F.at > (fz ? 2000 * F.queries.length + 1500 : 5000)) { F.tries++; F.phase = "idle"; if (info.input && info.input.tagName === "INPUT" && !info.input.readOnly) setValue(info.input, ""); }
      else idle(`${label}: searching the list for "${wanted}"...`);
      return false;
    }
    if (F.phase === "picked") {
      if (Date.now() - F.at < 450) return false;
      if (okVal(info.value) || (opts.anyFallback && info.value)) { F.phase = "done"; return true; }
      if (!F.kbd) { // click se na chuna gaya ho to keyboard se: Neeche-tir + Enter
        F.kbd = true; F.busy = true; status(`${label}: selecting with keyboard...`);
        bg({ type: "pressKeys", keys: ["ArrowDown", "Enter"] }).then(() => { F.busy = false; F.at = Date.now(); });
        return false;
      }
      F.kbd = false; F.tries++; F.phase = "idle"; return false;
    }
    return F.phase === "done";
  }

  // CA/Consumer number ka box: District/Type (nahi to Board) ke neeche wala khali input. strict=true: neeche kuch na mile to null.
  const DIST_RE2 = /^district(\s*\/\s*type)?$|^type$/i;
  function findNumInput(strict) {
    const dropdownInputs = Object.values(fsm).map((f) => f.input);
    const inputs = qsaAll("input").filter((i) => visible(i) && ["text", "tel", "number", ""].includes(i.type) && !isInHeader(i) && !i.value && !dropdownInputs.includes(i));
    const desc = (i) => `${i.placeholder} ${i.getAttribute("aria-label") || ""} ${i.name} ${i.id}`;
    const above = (fieldInfo(DIST_RE2) || fieldInfo(/electricity\s*board(?!s)|^board$|operator|discom|provider/i) || {}).input;
    const minTop = above ? above.getBoundingClientRect().bottom - 5 : -1e9; // upar wale dropdown ke neeche
    const below = inputs.filter((i) => i !== above && i.getBoundingClientRect().top >= minTop).sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    const pool = below.length ? below : (strict || above) ? [] : inputs;
    return pool.find((i) => /consumer|account|customer|number|\bca\b|k\s*no|\bid\b|\bbp\b|\bcrn\b/i.test(desc(i))) || pool[0] || null;
  }
  let numTries = 0, numBusy = false, boardOK = false, stateOK = false, distOK = false, numWait = 0, boardRetries = 0;
  function enterStep() {
    if (fetchedAt) return;
    if (item.state && !stateOK) { if (selectField("state", "State", /^state$/i, item.state)) stateOK = true; else return; }
    if (item.operator && !boardOK) { if (selectField("board", "Electricity Board", /electricity\s*board(?!s)|^board$|operator|discom|provider/i, item.operator)) { boardOK = true; numWait = Date.now(); } else return; }
    if (!distOK) {
      const DIST_RE = /^district(\s*\/\s*type)?$|^type$/i;
      const FD = fsm.district;
      if (FD && FD.touched && !FD.busy && findNumInput(true)) {
        // Page ne type ki hui value maan li aur number ka box aa gaya -> ab district dobara mat chuno (pehle yahi loop me fasta tha)
        distOK = true; numWait = Date.now();
      } else if (!numDone && !numBusy && !fieldInfo(DIST_RE) && !findNumInput(true) && Date.now() - numWait < 6000) {
        idle("Waiting for the next field (District/Type or Number)...");
        return;
      } else if (!numDone && !numBusy && !fieldInfo(DIST_RE) && Date.now() - numWait < 600) {
        return; // number box aa gaya, par District/Type shayad abhi render ho raha hai - thoda ruko
      } else if (fieldInfo(DIST_RE)) {
        // District/Type ka box dikha: Excel ki value, nahi to "Bill Payment" (default)
        if (selectField("district", "District/Type", DIST_RE, item.district || "Bill Payment", { anyFallback: !item.district, acceptAnyPrefilled: !item.district })) { distOK = true; numWait = Date.now(); } else return;
      }
    }

    if (!numDone) {
      const numIn = findNumInput(false);
      if (!numIn) {
        // Number ka box nahi aaya: matlab board shayad sahi se select nahi hua -> board dobara chuno
        if (numWait && Date.now() - numWait > 5000 && boardRetries < 2 && item.operator) {
          boardRetries++; boardOK = false; numWait = 0;
          const F = fsm.board; if (F) { F.phase = "idle"; F.typed = false; F.tries = 0; F.qi = 0; }
          status(`Number box did not appear, re-selecting the board (${boardRetries}/2)...`);
        } else idle("Looking for the number box...");
        return;
      }
      if (numBusy) return;
      numBusy = true; status(`Typing number: ${item.number}`);
      (async () => {
        await clickEl(numIn); // asli click se focus lo (sirf el.focus() se key events nahi pahunchte the)
        await new Promise((r) => setTimeout(r, 100));
        await trustedType(numIn, item.number);
        await new Promise((r) => setTimeout(r, 120));
        if ((numIn.value || "").replace(/\s/g, "") !== String(item.number).replace(/\s/g, "")) { // typing nahi pahunchi -> seedha value daalo
          numIn.focus(); setValue(numIn, String(item.number));
          numIn.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "0" }));
          await new Promise((r) => setTimeout(r, 120));
        }
        if ((numIn.value || "").trim()) { numDone = true; numAt = Date.now(); status(`Number entered: ${item.number}`); }
        else { numTries++; status(`Could not enter the number, retrying (${numTries})...`, "#b12704"); }
        numBusy = false;
      })();
      return;
    }
    if (Date.now() - numAt > 200) {
      const b = qsaAll("button,[role=button],input[type=submit]").filter((e) => visible(e) && /^proceed$/i.test(txt(e)) && !e.disabled)[0];
      if (b) {
        fetchedAt = Date.now();
        chrome.storage.local.get("queue", ({ queue }) => { if (queue && queue.idx === myIdx) { queue.fetchedIdx = myIdx; queue.fetchedAt = fetchedAt; chrome.storage.local.set({ queue }); } });
        b.click(); status("Fetching bill...");
      } else idle("Waiting for the Proceed button...");
    }
  }

  // ---- Step 2: result padho (due date + amount) ----
  // Sirf bayen "Pay Electricity Bill" card se padhte hain (Promo Codes ke "₹1", "₹19" galti se amount na ban jayein).
  // Amount ek INPUT me hota hai (innerText me nahi aata), isliye uski value padhte hain.
  const ERR = /(no (pending )?(bill|dues?)|bill (is )?already paid|invalid|not found|incorrect|unable to fetch|something went wrong|no outstanding|try again)/i;
  function formCard() {
    const btn = qsaAll("button,[role=button]").find((e) => visible(e) && /^proceed( to pay)?$/i.test(txt(e)));
    if (!btn) return null;
    let card = btn.parentElement;
    while (card && card.parentElement && card.parentElement !== document.body && !/promo codes/i.test(card.parentElement.innerText || "")) card = card.parentElement;
    return card;
  }
  // label ke saath wali value: label ke paas input ho to uski value, nahi to bagal wala text
  function readPair(card, labelRe, useInput = true) {
    const labs = [...card.querySelectorAll("*")].filter((e) => !e.children.length && visible(e) && labelRe.test(txt(e)));
    for (const lab of labs) {
      let box = lab.parentElement;
      for (let i = 0; useInput && i < 3 && box && box !== card; i++, box = box.parentElement) {
        const inp = box.querySelector("input:not([type=radio]):not([type=checkbox]):not([type=hidden])");
        if (inp && (inp.value || "").trim()) return inp.value.trim();
      }
      const n = lab.nextElementSibling;
      if (n && txt(n) && txt(n).length < 60) return txt(n);
      const par = lab.parentElement;
      if (par) { const t = txt(par).replace(txt(lab), "").replace(/\s+/g, " ").trim(); if (t && t.length < 60) return t; }
    }
    return "";
  }
  let lastRead = "", lastReadAt = 0, zeroAt = 0;
  function resultStep() {
    const elapsed = Date.now() - fetchedAt;
    if (elapsed < 600) return;
    const card = formCard();
    if (!card) { idle("Waiting for bill details..."); return; }
    const due = readPair(card, /^(due|last|payment)\s*(date|on)(\s*of\s*payment)?$/i, false);
    // Amount: pehle wahi purana tareeka (4-line wale bills me yahi chalta hai). Na mile to neeche ke tareeke, ek ke baad ek.
    // Koi bhi value tabhi maani jayegi jab wo sach me rakam lage (date jaisi "30 Nov 2026" nahi).
    const isMoney = (v) => { const t = String(v || "").replace(/rs\.?|inr|₹/gi, "").trim(); return /\d/.test(t) && !/[A-Za-z]{3,}/.test(t); };
    const toNum = (v) => parseFloat(String(v).replace(/[^\d.]/g, ""));
    const mainRe = /^((total|net|bill|current)\s*)?(amount|payable)(\s*(payable|due))?(\s*\(.*\))?$/i;
    const cardText = (card.innerText || "").replace(/\s+/g, " ");
    const skipInputs = Object.values(fsm).map((f) => f.input);
    const cands = [
      () => readPair(card, mainRe),
      () => readPair(card, /^(?!.*date).{0,30}(amount|payable|amt).{0,30}$/i), // "Amount to be paid", "Total Payable Amount" jaise naam
      () => { // card ka aisa input jisme rakam bhari ho (CA/Service number aur dropdown ke inputs chhodkar)
        const ins = [...card.querySelectorAll("input")].filter((i) => visible(i) && !skipInputs.includes(i) && isMoney(i.value) && String(i.value).replace(/\D/g, "") !== String(item.number).replace(/\D/g, ""));
        return ins.length ? ins[ins.length - 1].value : "";
      },
      () => { const m = cardText.match(/(?:amount|payable)(?!\s*date)[^\d₹]{0,25}(?:₹|Rs\.?)?\s*([\d,]+(?:\.\d{1,2})?)/i); return m ? m[1] : ""; },
      () => { const m = cardText.match(/(?:₹|Rs\.?)\s*([\d,]+(?:\.\d{1,2})?)/); return m ? m[1] : ""; },
    ];
    let amtRaw = "";
    for (const c of cands) { const v = c(); if (isMoney(v) && !isNaN(toNum(v))) { amtRaw = v; break; } }
    const amtNum = amtRaw ? toNum(amtRaw) : NaN;
    const name = readPair(card, /^(consumer|customer)\s*name$/i, false);
    const hasDetails = /bill details/i.test(card.innerText || "") || !!due;
    if (hasDetails && !isNaN(amtNum)) {
      // value 2 baar same dikhe (page abhi load ho rahi ho to adhuri value na pakdein)
      const sig = `${due}|${amtNum}|${name}`;
      if (sig !== lastRead) { lastRead = sig; lastReadAt = Date.now(); idle("Reading bill details..."); return; }
      if (Date.now() - lastReadAt < 300) return;
      finish("done", { due: due || "-", amount: amtNum, name: name || "", note: "" });
      return;
    }
    // If Paytm shows an editable Amount box (nothing to fetch / amount must be typed), put 0 in it and move to the next bill.
    const numDigits = String(item.number).replace(/\D/g, "");
    const nearText = (i) => { let t = "", b = i; for (let k = 0; k < 2 && b && b !== card; k++, b = b.parentElement) t += " " + (b.innerText || ""); return t.slice(0, 120); };
    const amtBox = isNaN(amtNum) ? [...card.querySelectorAll("input")].find((i) => visible(i) && !skipInputs.includes(i) && !["radio", "checkbox", "hidden", "submit"].includes(i.type)
      && (i.value || "").replace(/\D/g, "") !== numDigits && /amount|\bamt\b|₹|\brs\b/i.test(`${i.placeholder} ${i.getAttribute("aria-label") || ""} ${i.name} ${i.id} ${nearText(i)}`)) : null;
    if (amtBox) {
      if (!zeroAt) { zeroAt = Date.now(); idle("Amount box appeared, setting it to 0..."); return; }
      if (Date.now() - zeroAt < 350) return;
      try { setValue(amtBox, "0"); } catch (_) {}
      finish("done", { due: due || "-", amount: 0, name: name || "", note: "Amount box asked - set to 0" });
      return;
    } else zeroAt = 0;
    const e = (card.innerText || "").replace(/\s+/g, " ").match(ERR);
    if (e && elapsed > 2000) { finish("error", { note: e[0], due: "-", amount: null, name: "" }); return; }
    if (elapsed > 25000) { finish("error", { note: "Bill details did not load (25s)", due: "-", amount: null, name: "" }); return; }
    idle("Waiting for bill details...");
  }

  // ---- Loop ----
  function step() {
    if (stopped) return;
    const started = Math.max(q0.startedAt || 0, 0);
    if (Date.now() < started) return; // agle bill ke liye thoda ruko
    if (Date.now() - started > 60000) { finish("error", { note: "Timeout - the page looks different than expected", due: "-", amount: null, name: "" }); return; }
    if (fetchedAt) resultStep(); else enterStep();
  }
  chrome.storage.onChanged.addListener((ch) => { // side panel se STOP / Rukao dabane par turant band
    if (ch.queue && ch.queue.newValue && !ch.queue.newValue.active && !stopped) { stopAll(); if (isTop) chrome.storage.local.set({ lastStatus: { t: "⏹ Stopped.", c: "#b12704", at: Date.now() } }); }
  });
  if (isTop) status(`Bill ${myIdx + 1}/${q0.items.length}: ${[item.state, item.operator].filter(Boolean).join(" / ")} • ${item.number}`);
  step();
  obs = new MutationObserver(() => step());
  obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
  timer = setInterval(step, 100);
})();
