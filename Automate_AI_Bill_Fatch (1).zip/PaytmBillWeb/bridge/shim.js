// Extension ke content.js ko bina badle chalane ke liye chrome.* ka chhota nakli version.
// storage / messages Node server (server.js) tak jate hain.
(() => {
  if (window.__shim) return; window.__shim = 1;
  const ls = [];
  window.__fireChanged = (ch) => ls.forEach((f) => { try { f(ch, "local"); } catch (_) {} });
  window.chrome = {
    storage: {
      onChanged: { addListener: (f) => ls.push(f) },
      local: {
        get: (keys, cb) => { const p = window.__stGet(keys); if (cb) { p.then(cb); return; } return p; },
        set: (o, cb) => { const p = window.__stSet(o); if (cb) { p.then(cb); return; } return p; },
      },
    },
    runtime: {
      onMessage: { addListener() {} },
      sendMessage: (m, cb) => { const p = window.__bgMsg(m).catch(() => ({ ok: false })); if (cb) { p.then(cb); return; } },
    },
  };
})();
