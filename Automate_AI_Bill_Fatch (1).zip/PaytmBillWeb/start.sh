#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Please install Node.js: https://nodejs.org"; exit 1; }
[ -d node_modules ] || npm install
(sleep 2; (open http://localhost:3000 || xdg-open http://localhost:3000) >/dev/null 2>&1) &
node server.js
