// Board ke naam se state pehchano (Excel me State na likha ho tab). State ke naam wahi hain jo Paytm ki State list me dikhte hain.
// Naya board jodna ho to neeche TABLE me ek line add kar do: ["keyword", "State"]  (keyword chhote akshar, bina symbol ke)
const BoardState = (() => {
  const TABLE = [
    // Paytm ke board code (bina space wale naam) - jaise BSESRajdhani, TATAPOWERLTD_DELHI
    ["adanielectricitymumbai", "Maharashtra"], ["best", "Maharashtra"], ["tatapowerltd mumbai", "Maharashtra"],
    ["bsesrajdhani", "New Delhi"], ["bsesyamuna", "New Delhi"], ["tatapowerltd delhi", "New Delhi"],
    ["cescom", "Karnataka"], ["cese", "West Bengal"], ["chennaimwaters", "Tamil Nadu"], ["jkpdd", "Jammu & Kashmir"], ["jusco", "Jharkhand"],
    ["mpmkvv", "Madhya Pradesh"], ["mppkvv", "Madhya Pradesh"],
    ["torrentpower agra", "Uttar Pradesh"], ["torrentpower ahmd", "Gujarat"],
    ["uppclu dvvnl", "Uttar Pradesh (Urban)"], ["uppclu mvvnl", "Uttar Pradesh (Urban)"], ["uppclu puvnl", "Uttar Pradesh (Urban)"], ["uppclu pvvnl", "Uttar Pradesh (Urban)"],
    // New Delhi
    ["bses rajdhani", "New Delhi"], ["bses yamuna", "New Delhi"], ["bses", "New Delhi"], ["tata power ddl", "New Delhi"], ["tpddl", "New Delhi"],
    ["ndmc", "New Delhi"], ["new delhi municipal council", "New Delhi"],
    // West Bengal (CESC = Kolkata; Mysore wala neeche Karnataka me)
    ["cesc", "West Bengal"], ["wbsedcl", "West Bengal"], ["west bengal state electricity", "West Bengal"],
    // Maharashtra
    ["msedcl", "Maharashtra"], ["mahavitaran", "Maharashtra"], ["mseb", "Maharashtra"], ["adani electricity", "Maharashtra"],
    ["best undertaking", "Maharashtra"], ["brihanmumbai electric", "Maharashtra"], ["tata power mumbai", "Maharashtra"], ["tata power", "Maharashtra"],
    // Gujarat
    ["torrent power", "Gujarat"], ["ugvcl", "Gujarat"], ["dgvcl", "Gujarat"], ["mgvcl", "Gujarat"], ["pgvcl", "Gujarat"],
    ["uttar gujarat vij", "Gujarat"], ["dakshin gujarat vij", "Gujarat"], ["madhya gujarat vij", "Gujarat"], ["paschim gujarat vij", "Gujarat"],
    // Uttar Pradesh
    ["uppcl urban", "Uttar Pradesh (Urban)"], ["uppcl", "Uttar Pradesh (Urban)"], ["npcl", "Uttar Pradesh"], ["noida power", "Uttar Pradesh"],
    ["kesco", "Uttar Pradesh"], ["kanpur electricity supply", "Uttar Pradesh"], ["pvvnl", "Uttar Pradesh"], ["dvvnl", "Uttar Pradesh"],
    ["mvvnl", "Uttar Pradesh"], ["puvvnl", "Uttar Pradesh"],
    // Karnataka
    ["bescom", "Karnataka"], ["mescom", "Karnataka"], ["hescom", "Karnataka"], ["gescom", "Karnataka"], ["cesc mysore", "Karnataka"],
    ["chamundeshwari", "Karnataka"], ["bangalore electricity", "Karnataka"],
    // South
    ["tangedco", "Tamil Nadu"], ["tneb", "Tamil Nadu"], ["tnpdcl", "Tamil Nadu"],
    ["tsspdcl", "Telangana"], ["tsnpdcl", "Telangana"], ["tgspdcl", "Telangana"], ["tgnpdcl", "Telangana"],
    ["apspdcl", "Andhra Pradesh"], ["apepdcl", "Andhra Pradesh"], ["apcpdcl", "Andhra Pradesh"], ["ttd electricity", "Andhra Pradesh"],
    ["kseb", "Kerala"], ["kerala state electricity", "Kerala"], ["puducherry electricity", "Pondicherry"],
    // Rajasthan / Haryana / Punjab / HP / UK / J&K / Chandigarh
    ["jvvnl", "Rajasthan"], ["avvnl", "Rajasthan"], ["jdvvnl", "Rajasthan"], ["jodhpur vidyut", "Rajasthan"], ["jaipur vidyut", "Rajasthan"],
    ["ajmer vidyut", "Rajasthan"], ["bkesl", "Rajasthan"], ["kedl", "Rajasthan"],
    ["uhbvn", "Haryana"], ["dhbvn", "Haryana"], ["uttar haryana", "Haryana"], ["dakshin haryana", "Haryana"],
    ["pspcl", "Punjab"], ["punjab state power", "Punjab"],
    ["hpsebl", "Himachal Pradesh"], ["himachal pradesh state electricity", "Himachal Pradesh"],
    ["upcl", "Uttarakhand"], ["uttarakhand power", "Uttarakhand"],
    ["jpdcl", "Jammu & Kashmir"], ["kpdcl", "Jammu & Kashmir"], ["jammu power", "Jammu & Kashmir"], ["kashmir power", "Jammu & Kashmir"],
    ["chandigarh electricity", "Chandigarh"], ["chandigarh power", "Chandigarh"],
    // Madhya Pradesh / Chhattisgarh / Bihar / Jharkhand / Odisha / Assam / Goa
    ["mppkvvcl", "Madhya Pradesh"], ["mpmkvvcl", "Madhya Pradesh"], ["mpwz", "Madhya Pradesh"], ["mpez", "Madhya Pradesh"], ["mpcz", "Madhya Pradesh"],
    ["cspdcl", "Chhattisgarh"],
    ["nbpdcl", "Bihar"], ["sbpdcl", "Bihar"], ["north bihar power", "Bihar"], ["south bihar power", "Bihar"],
    ["jbvnl", "Jharkhand"], ["jharkhand bijli", "Jharkhand"],
    ["tpcodl", "Odisha"], ["tpnodl", "Odisha"], ["tpsodl", "Odisha"], ["tpwodl", "Odisha"],
    ["apdcl", "Assam"], ["assam power", "Assam"], ["goa electricity", "Goa"],
    ["meecl", "Meghalaya"], ["tsecl", "Tripura"],
  ];
  // Board ke naam me state ka naam likha ho (jaise "Central Power, Andhra Pradesh") to bhi chalega
  const STATES = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh",
    "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
    "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Lakshadweep"];
  const norm = (s) => (s || "").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").trim();
  const has = (text, kw) => ` ${text} `.includes(` ${norm(kw)} `);

  // learned = { "<board naam>": "State" }  (Excel me jahan State likha tha wahan se seekha hua) -> sabse pehle yahi dekhte hain
  function infer(operator, learned) {
    const t = norm(operator);
    if (!t) return "";
    if (learned && learned[t]) return learned[t];
    let best = null;
    for (const [kw, st] of TABLE) if (has(t, kw) && (!best || norm(kw).length > best.len)) best = { len: norm(kw).length, st };
    for (const st of STATES) if (has(t, st) && (!best || norm(st).length > best.len)) best = { len: norm(st).length, st };
    if (!best && /\bdelhi\b/.test(t)) best = { st: "New Delhi" };
    return best ? best.st : "";
  }
  return { infer, norm };
})();
if (typeof module !== "undefined") module.exports = BoardState;
