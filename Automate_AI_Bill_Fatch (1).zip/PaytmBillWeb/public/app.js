const $ = (id) => document.getElementById(id);
let S = { queue: null }, lastStatusAt = 0, editing = false;
const api = async (path, body) => {
  const r = await fetch("/api/" + path, { method: "POST", headers: { "Content-Type": "application/json", "x-app": "1" }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error || "Error");
  return j;
};
const COL = { "#111": "", "#b12704": "#ff8a7a", "#067d62": "#4ee3b0" };
function showStatus(s) {
  if (!s) return;
  $("status").textContent = s.t; $("status").style.color = s.c in COL ? COL[s.c] : (s.c || "");
  $("when").textContent = new Date(s.at).toLocaleTimeString();
}
const say = (t, c) => showStatus({ t, c, at: Date.now() });

function render() {
  const q = S.queue, t = $("tbl"); t.innerHTML = "";
  $("count").textContent = q ? `(${q.items.filter((b) => b.status !== "pending").length}/${q.items.length})` : "";
  if (!q || !q.items.length) return;
  const head = t.insertRow();
  ["#", "State", "Board", "Type", "Number", "Name", "Due date", "₹", "Status"].forEach((h) => { const th = document.createElement("th"); th.textContent = h; head.appendChild(th); });
  q.items.forEach((b, i) => {
    const r = t.insertRow();
    if (q.active && i === q.idx) r.className = "cur";
    const label = b.status === "done" ? "✔" + (b.note ? " " + b.note : "") : b.status === "error" ? "⚠ " + (b.note || "error") : "pending";
    [i + 1, (b.state || "") + (b.stateAuto ? " ⚙" : ""), b.operator, b.district || "", b.number, b.name || "", b.due || "", b.amount ?? "", label].forEach((v, k) => {
      const td = r.insertCell(); td.textContent = v; if (k === 8) td.className = b.status;
    });
  });
}

async function poll() {
  try {
    const d = await (await fetch("/api/state")).json();
    S = d.store;
    if (!editing) { $("startUrl").value = S.startUrl || ""; $("delay").value = S.delay ?? 1; }
    if (document.activeElement !== $("hide")) $("hide").checked = S.hide !== false;
    $("dot").className = "dot" + (d.browser ? " on" : ""); $("brw").textContent = d.browser ? "Paytm window is open" : "Paytm window is closed";
    if (S.lastStatus && S.lastStatus.at !== lastStatusAt) { lastStatusAt = S.lastStatus.at; showStatus(S.lastStatus); }
    render();
  } catch (_) { $("status").textContent = "Lost connection to the server. Please run start.bat again."; }
}
setInterval(poll, 1000); poll();
["startUrl", "delay"].forEach((id) => { $(id).onfocus = () => (editing = true); $(id).onblur = () => (editing = false); });

const run = (fn) => async () => { try { await fn(); } catch (e) { say(e.message, "#b12704"); } poll(); };
const saveSettings = () => api("settings", { startUrl: $("startUrl").value.trim(), delay: isNaN(Number($("delay").value)) ? 1 : Number($("delay").value), hide: $("hide").checked });

$("open").onclick = run(async () => { say("Opening Paytm..."); await api("open"); });
$("start").onclick = run(async () => { await saveSettings(); await api("start"); });
$("show").onclick = run(() => api("show"));
$("hide").onchange = run(async () => { await saveSettings(); if (!$("hide").checked) await api("show"); });
$("stop").onclick = run(() => api("stop"));
$("retry").onclick = run(async () => { await saveSettings(); await api("retry"); });
$("reset").onclick = run(() => api("clear"));

$("file").onchange = run(async () => {
  const f = $("file").files[0]; if (!f) return;
  const rows = await BillParse.parseFile(f);
  let learned = {}; try { learned = JSON.parse(localStorage.getItem("learnedBoards") || "{}"); } catch (_) {}
  rows.forEach((b) => { if (b.state && b.operator) learned[BoardState.norm(b.operator)] = b.state; });
  let auto = 0, unknown = 0;
  const items = rows.map((b) => {
    const it = { state: b.state || "", operator: b.operator, district: b.district || "", number: b.number, status: "pending", due: "", amount: null, name: "", note: "" };
    if (!it.state) {
      it.state = BoardState.infer(b.operator, learned);
      if (it.state) { it.stateAuto = true; auto++; }
      else { it.status = "error"; it.noState = true; it.note = "State not detected - add State in Excel"; it.due = "-"; unknown++; }
    }
    return it;
  });
  if (!items.length) { say("No bills found in the file. Check the column headings.", "#b12704"); return; }
  try { localStorage.setItem("learnedBoards", JSON.stringify(learned)); } catch (_) {}
  await api("queue", { items });
  say(`${items.length} bills loaded.` + (auto ? ` State auto-detected for ${auto}.` : "") + (unknown ? ` ⚠ State not detected for ${unknown} (add State in Excel).` : "") + " Now click “Start Fetch”.", unknown ? "#b12704" : "#067d62");
});

$("xlsx").onclick = () => {
  const q = S.queue; if (!q) { say("The report is empty.", "#b12704"); return; }
  const rows = [["State", "Electricity Board", "Selected on Paytm", "Paytm Board Code", "District/Type", "CA / Consumer Number", "Customer Name", "Due Date", "Amount (₹)", "Status", "Note"]];
  q.items.forEach((b) => rows.push([b.state || "", b.operator, b.paytmBoard || "", b.boardCode || "", b.district || "", b.number, b.name || "", b.due || "", b.amount ?? "", b.status === "done" ? "OK" : b.status === "error" ? "Error" : "Pending", b.note || ""]));
  const a = document.createElement("a");
  a.href = URL.createObjectURL(XlsxWrite.build(rows));
  a.download = `bill_report_${new Date().toISOString().slice(0, 10)}.xlsx`;
  a.click();
};

// Sample Excel: click the button to download a ready-to-edit file in the right format
$("sample").onclick = () => {
  const rows = [
    ["State", "Electricity Board", "District/Type", "CA / Consumer Number"],
    ["Maharashtra", "MSEDCL", "", "170012345678"],
    ["New Delhi", "BSESRajdhani", "", "100012345"],
    ["Uttar Pradesh", "UPPCLU_MVVNL", "", "1234567890"],
    ["", "Tata Power Mumbai", "", "9001234567"],
    ["", "Torrent Power Ahmedabad", "", "12345678901"],
  ];
  const a = document.createElement("a");
  a.href = URL.createObjectURL(XlsxWrite.build(rows));
  a.download = "sample_bills.xlsx";
  a.click();
  say("Sample Excel downloaded. Replace the sample rows with your boards and numbers (State and District/Type are optional).", "#067d62");
};
