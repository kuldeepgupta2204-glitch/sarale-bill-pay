// Small .xlsx / CSV reader (no external library needed)
const BillParse = (() => {
  const td = new TextDecoder();

  async function unzip(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    let e = u8.length - 22;
    while (e >= 0 && dv.getUint32(e, true) !== 0x06054b50) e--;
    if (e < 0) throw new Error("This is not a valid .xlsx file");
    const cnt = dv.getUint16(e + 10, true);
    let p = dv.getUint32(e + 16, true);
    const files = {};
    for (let i = 0; i < cnt; i++) {
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
      const nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      files[td.decode(u8.subarray(p + 46, p + 46 + nlen))] = { method, csize, lho };
      p += 46 + nlen + elen + clen;
    }
    return {
      names: Object.keys(files),
      async read(name) {
        const f = files[name];
        if (!f) return null;
        const nl = dv.getUint16(f.lho + 26, true), el = dv.getUint16(f.lho + 28, true);
        const start = f.lho + 30 + nl + el;
        const data = u8.subarray(start, start + f.csize);
        if (f.method === 0) return td.decode(data);
        const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
        return td.decode(new Uint8Array(await new Response(stream).arrayBuffer()));
      },
    };
  }

  const unesc = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  function colIdx(ref) {
    let n = 0;
    for (const ch of /^[A-Z]+/.exec(ref)[0]) n = n * 26 + ch.charCodeAt(0) - 64;
    return n - 1;
  }
  const textOf = (xml) => [...xml.matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((m) => unesc(m[1])).join("");

  async function xlsxRows(buf) {
    const z = await unzip(buf);
    const ss = await z.read("xl/sharedStrings.xml");
    const shared = ss ? [...ss.matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => textOf(m[1])) : [];
    const sheetName = z.names.filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort()[0];
    if (!sheetName) throw new Error("Sheet not found");
    const xml = await z.read(sheetName);
    const rows = [];
    for (const rm of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
      const row = [];
      for (const cm of rm[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const attrs = cm[1], inner = cm[2] || "";
        const ref = /r="([A-Z]+\d+)"/.exec(attrs);
        if (!ref) continue;
        const t = (/t="(\w+)"/.exec(attrs) || [])[1];
        let val = "";
        if (t === "inlineStr") val = textOf(inner);
        else {
          const v = /<v>([\s\S]*?)<\/v>/.exec(inner);
          if (v) val = t === "s" ? shared[Number(v[1])] || "" : unesc(v[1]);
        }
        row[colIdx(ref[1])] = val;
      }
      rows.push(row);
    }
    return rows.map((r) => Array.from(r, (x) => (x === undefined ? "" : x)));
  }

  function csvRows(text) {
    const rows = [];
    for (const line of text.replace(/^\uFEFF/, "").split(/\r?\n/)) {
      if (!line.trim()) continue;
      const out = []; let cur = "", q = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (q) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') q = false; else cur += ch; }
        else if (ch === '"') q = true;
        else if (ch === "," || ch === "\t" || ch === ";") { out.push(cur); cur = ""; }
        else cur += ch;
      }
      out.push(cur); rows.push(out);
    }
    return rows;
  }

  function cleanNumber(v) {
    let s = String(v ?? "").trim();
    if (/^\d+\.0+$/.test(s)) s = s.split(".")[0];
    if (/^\d+(\.\d+)?e\+?\d+$/i.test(s)) s = Number(s).toFixed(0);
    return s;
  }

  function toItems(rows) {
    const hdrIdx = rows.findIndex((r) => r.some((c) => /state|operator|board|biller|company|provider|consumer|account|number|district/i.test(String(c))));
    let stC = 0, opC = 1, numC = 2, distC = -1, amtC = -1, start = 0;
    if (hdrIdx >= 0) {
      const h = rows[hdrIdx].map((c) => String(c));
      const used = [];
      const find = (re) => { const i = h.findIndex((c, k) => !used.includes(k) && re.test(c)); if (i >= 0) used.push(i); return i; };
      stC = find(/state|rajya/i);
      opC = find(/operator|board|biller|company|provider|discom/i);
      numC = find(/number|consumer|account|k\s*no|\bca\b|\bid\b/i);
      distC = find(/district|type/i);
      amtC = find(/amount|due|rs|₹/i);
      start = hdrIdx + 1;
    } else if ((rows[0] || []).length < 3) { stC = -1; opC = 0; numC = 1; }
    else if ((rows[0] || []).length >= 4) { distC = 2; numC = 3; }
    const items = [];
    for (const r of rows.slice(start)) {
      const number = cleanNumber(r[numC]);
      if (!number) continue;
      const amt = amtC >= 0 ? parseFloat(String(r[amtC] ?? "").replace(/[₹,\s]/g, "")) : NaN;
      items.push({
        state: stC >= 0 ? String(r[stC] ?? "").trim() : "",
        operator: opC >= 0 ? String(r[opC] ?? "").trim() : "",
        district: distC >= 0 ? String(r[distC] ?? "").trim() : "",
        number, amount: isNaN(amt) ? null : amt, status: "pending",
      });
    }
    return items;
  }

  async function parseFile(file) {
    const buf = await file.arrayBuffer();
    const rows = /\.csv$/i.test(file.name) ? csvRows(td.decode(buf)) : await xlsxRows(buf);
    return toItems(rows);
  }
  return { parseFile, xlsxRows, csvRows, toItems };
})();
if (typeof module !== "undefined") module.exports = BillParse;
