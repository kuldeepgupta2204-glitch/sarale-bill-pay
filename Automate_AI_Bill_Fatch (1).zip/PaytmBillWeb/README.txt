Automate AI Bill Fatch - Bulk Electricity Bill Fetch (local web app)

One-time setup
1. Google Chrome and Node.js (LTS) must be installed. Node.js: https://nodejs.org
2. Extract this folder.

How to run
1. Windows: double-click start.bat.   Mac/Linux: ./start.sh
   (The first time, "npm install" runs automatically. It takes a little while.)
2. Your browser opens http://localhost:3000
3. Click "Open Paytm / Log in" -> Paytm opens in a separate Chrome window -> log in there.
4. Click "Download sample Excel" to get a ready-made file, fill it, then upload it
   (Electricity Board + CA/Consumer Number are required, the rest is optional).
5. Click "Start Fetch". To stop, click the red STOP button at the top.
6. When done, click "Download Excel report".

Good to know
- If Paytm asks for an Amount after a bill is fetched, the app puts 0 in it, saves the row
  (Note: "Amount box asked - set to 0") and moves on to the next bill. No payment is ever made.
- Board names do not have to match Paytm exactly. Short forms, spelling mistakes and codes
  (UPPCL, Mahavitran, BSESRajdhani, TATAPOWERLTD_MUMBAI ...) are matched to the closest Paytm board.
  The report shows which board was actually selected. Add new names in bridge/content.js (CODES / ALIAS tables).
- Hidden Paytm window: while fetching, the Paytm Chrome window is moved off-screen so it does not get in your way (untick "Hide the Paytm window while fetching" to see it). Click "Show Paytm window" any time to bring it back, e.g. if you need to log in again. "Open Paytm / Log in" also shows it.
- You log in inside Paytm's own window. This app never receives your password or OTP.
- The app runs only on your computer (localhost). Nobody else can use it.
- Do not close the automation Chrome window while it runs (it is just hidden), and do not click inside it.
- The login/session is kept in the "chrome-profile" folder. Delete that folder to log out.
- To quit, press Ctrl+C in the black start.bat window.
- Speed: lower "Gap between bills" (default 1 second, minimum 0.3) to run faster.
