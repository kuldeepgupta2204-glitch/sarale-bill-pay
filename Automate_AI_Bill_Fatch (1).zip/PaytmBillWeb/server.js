// Automate AI Bill Fatch - bulk electricity bill fetch (local web app)
// Web page: http://localhost:3000   |   Paytm opens in a real Chrome window; you log in yourself.
const http = require("http"), fs = require("fs"), path = require("path");
let pw; try { pw = require("playwright-core"); } catch (_) { pw = require("playwright"); }

const PORT = Number(process.env.PORT) || 3000;
const PUB = path.join(__dirname, "public");
const DATA = path.join(__dirname, "data.json");
const PROFILE = path.join(__dirname, "chrome-profile"); // login yahin yaad rehta hai
const DEFAULT_URL = "https://paytm.com/electricity-bill-payment";
const ALLOW = ["paytm.com", ...(process.env.ALLOW_HOST || "").split(",").filter(Boolean)];
const okHost = (h) => ALLOW.some((a) => h === a || h.endsWith("." + a));

let store = { queue: null, lastStatus: null, startUrl: DEFAULT_URL, delay: 1, hide: true };
try { Object.assign(store, JSON.parse(fs.readFileSync(DATA, "utf8"))); } catch (_) {}
let saveT; const persist = () => { clearTimeout(saveT); saveT = setTimeout(() => fs.writeFile(DATA, JSON.stringify(store), () => {}), 300); };
const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const say = (t, c) => { store.lastStatus = { t, c: c || "#111", at: Date.now() }; persist(); };

let ctx = null, page = null, epoch = 0, cdp = null;

// ---------- window hide / show ----------
// Hide = move the Chrome window far off-screen (keeps the page fully active, unlike minimizing). Show = bring it back, maximized.
async function winCmd(mode) {
  if (!ctx || !page || page.isClosed()) return;
  try {
    if (!cdp) cdp = await ctx.newCDPSession(page);
    const { windowId } = await cdp.send("Browser.getWindowForTarget");
    const set = (bounds) => cdp.send("Browser.setWindowBounds", { windowId, bounds });
    await set({ windowState: "normal" });
    if (mode === "hide") await set({ left: -32000, top: -32000, width: 1366, height: 900 });
    else { await set({ left: 60, top: 40, width: 1280, height: 860 }); await set({ windowState: "maximized" }); }
  } catch (e) {
    cdp = null;
    if (mode === "hide") { try { cdp = await ctx.newCDPSession(page); const { windowId } = await cdp.send("Browser.getWindowForTarget"); await cdp.send("Browser.setWindowBounds", { windowId, bounds: { windowState: "minimized" } }); } catch (_) { cdp = null; } }
  }
}

// ---------- browser ----------
function broadcast(ch) {
  if (!page) return;
  for (const f of page.frames()) f.evaluate((c) => window.__fireChanged && window.__fireChanged(c), ch).catch(() => {});
}
async function ensureBrowser(hidden) {
  if (ctx && page && !page.isClosed()) return;
  cdp = null;
  const keepAlive = ["--disable-background-timer-throttling", "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows"];
  const pos = hidden ? ["--window-position=-32000,-32000", "--window-size=1366,900"] : ["--start-maximized"];
  const base = { headless: !!process.env.HEADLESS, viewport: null, args: ["--disable-blink-features=AutomationControlled", ...pos, ...keepAlive], ignoreDefaultArgs: ["--enable-automation"] };
  const tries = process.env.BROWSER_CHANNEL ? [process.env.BROWSER_CHANNEL] : ["chrome", "msedge"];
  let lastErr;
  for (const ch of tries) {
    try { ctx = await pw.chromium.launchPersistentContext(PROFILE, ch === "chromium" ? base : { ...base, channel: ch }); lastErr = null; break; }
    catch (e) { lastErr = e; }
  }
  if (lastErr) throw new Error("Could not open Chrome/Edge. Is Google Chrome installed? (" + String(lastErr.message).split("\n")[0] + ")");
  ctx.on("close", () => { ctx = null; page = null; if (store.queue && store.queue.active) { store.queue.active = false; persist(); } });

  // Page se aane wale sawal: sirf Paytm (ya ALLOW_HOST) ke page ko jawab milega
  const guard = (src) => { try { return okHost(new URL(src.frame.url()).hostname); } catch (_) { return false; } };
  await ctx.exposeBinding("__stGet", async (src, keys) => {
    if (!guard(src)) return {};
    const arr = typeof keys === "string" ? [keys] : Array.isArray(keys) ? keys : Object.keys(store);
    const out = {}; for (const k of arr) if (k in store) out[k] = clone(store[k]);
    return out;
  });
  await ctx.exposeBinding("__stSet", async (src, o) => {
    if (!guard(src)) return;
    for (const [k, v] of Object.entries(o || {})) { store[k] = clone(v); if (k === "queue") broadcast({ queue: { newValue: clone(v) } }); }
    persist();
  });
  await ctx.exposeBinding("__bgMsg", async (src, m) => {
    if (!guard(src) || !page) return { ok: false };
    try {
      const my = epoch;
      if (m.type === "typeText") {
        if (m.clear) { await page.keyboard.press("Backspace"); await sleep(15); }
        for (const ch of String(m.text)) { if (epoch !== my) return { ok: false }; await page.keyboard.type(ch); await sleep(4); }
        return { ok: true };
      }
      if (m.type === "clickAt") { await page.mouse.move(m.x, m.y); await page.mouse.down(); await sleep(20); await page.mouse.up(); return { ok: true }; }
      if (m.type === "pressKeys") { for (const k of m.keys) { await page.keyboard.press(k); await sleep(70); } return { ok: true }; }
      if (m.type === "navigate") { page.goto(m.url).catch(() => {}); return { ok: true }; }
      if (m.type === "detach") return { ok: true };
    } catch (e) { return { ok: false, error: String(e) }; }
    return { ok: false };
  });
  const shim = fs.readFileSync(path.join(__dirname, "bridge", "shim.js"), "utf8");
  const content = fs.readFileSync(path.join(__dirname, "bridge", "content.js"), "utf8");
  await ctx.addInitScript({
    content: `(function(){ var ALLOW=${JSON.stringify(ALLOW)}; var h=location.hostname; if(!ALLOW.some(function(a){return h===a||h.endsWith("."+a);})) return;\n${shim}\n` +
      `document.addEventListener("DOMContentLoaded", function(){\n${content}\n});})();`,
  });
  page = ctx.pages()[0] || (await ctx.newPage());
}

// ---------- queue actions ----------
async function begin() {
  const q = store.queue;
  if (!q) throw new Error("Upload an Excel file first.");
  const i = q.items.findIndex((b) => b.status === "pending");
  if (i < 0) throw new Error("No pending bills.");
  await ensureBrowser(store.hide !== false);
  Object.assign(q, { idx: i, active: true, fails: 0, startUrl: store.startUrl, delay: store.delay, startedAt: Date.now(), fetchedIdx: -1 });
  persist();
  say("Starting...");
  page.goto(store.startUrl).catch(() => {});
  if (store.hide !== false) winCmd("hide"); // Paytm window goes out of sight while fetching
}
function stopNow() {
  epoch++;
  if (store.queue) store.queue.active = false;
  broadcast({ queue: { newValue: clone(store.queue) } });
  say("⏹ Stopped. Click “Start Fetch” to run again.", "#b12704");
}

// ---------- http ----------
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".jpg": "image/jpeg", ".css": "text/css", ".png": "image/png" };
const readBody = (req) => new Promise((res) => { let b = ""; req.on("data", (d) => { b += d; if (b.length > 20e6) req.destroy(); }); req.on("end", () => { try { res(JSON.parse(b || "{}")); } catch (_) { res({}); } }); });
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };

const server = http.createServer(async (req, res) => {
  // sirf isi computer se (localhost) use ho sakta hai
  const host = (req.headers.host || "").split(":")[0];
  if (host !== "localhost" && host !== "127.0.0.1") { res.writeHead(403); res.end("forbidden"); return; }
  const url = new URL(req.url, "http://localhost");
  try {
    if (url.pathname.startsWith("/api/")) {
      if (req.method === "GET" && url.pathname === "/api/state") return send(res, 200, { store, browser: !!(ctx && page && !page.isClosed()) });
      if (req.method !== "POST") return send(res, 405, { error: "POST required" });
      if (req.headers["x-app"] !== "1") return send(res, 403, { error: "forbidden" }); // doosri website se POST na ho paye
      const body = await readBody(req);
      switch (url.pathname) {
        case "/api/queue": store.queue = { items: body.items || [], idx: 0, active: false, fails: 0 }; persist(); break;
        case "/api/settings": store.startUrl = String(body.startUrl || DEFAULT_URL); store.delay = isNaN(Number(body.delay)) ? 1 : Math.max(0.3, Number(body.delay)); store.hide = body.hide !== false; persist(); break;
        case "/api/open": await ensureBrowser(false); page.goto("https://paytm.com").catch(() => {}); await winCmd("show"); say("Paytm is open. Log in in that window, then click “Start Fetch”.", "#067d62"); break;
        case "/api/start": await begin(); break;
        case "/api/show": await winCmd("show"); say("Paytm window is now visible."); break;
        case "/api/hide": await winCmd("hide"); say("Paytm window hidden."); break;
        case "/api/stop": stopNow(); break;
        case "/api/retry": if (store.queue) store.queue.items.forEach((b) => { if (b.status === "error" && !b.noState) { b.status = "pending"; b.note = ""; } }); persist(); await begin(); break;
        case "/api/clear": stopNow(); store.queue = null; persist(); say("Cleared."); break;
        default: return send(res, 404, { error: "not found" });
      }
      return send(res, 200, { ok: true });
    }
    let p = path.normalize(path.join(PUB, url.pathname === "/" ? "index.html" : url.pathname));
    if (!p.startsWith(PUB) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); res.end("not found"); return; }
    res.writeHead(200, { "Content-Type": MIME[path.extname(p)] || "application/octet-stream" });
    fs.createReadStream(p).pipe(res);
  } catch (e) { send(res, 500, { error: e.message }); }
});
server.listen(PORT, "127.0.0.1", () => console.log(`\n  Web page: http://localhost:${PORT}\n  (Press Ctrl+C in this window to stop)\n`));
